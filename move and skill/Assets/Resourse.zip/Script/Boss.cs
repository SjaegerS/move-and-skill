using System.Collections;
using UnityEngine;

// 보스: 큰 덩치의 근접형. 평소엔 플레이어를 추적하고,
// 일정 시간마다 스페셜 무브(완전 투명화 -> 타겟 위치 경고 -> 낙하 애니메이션 및 범위 공격)를 사용.
public class Boss : MonoBehaviour
{
    [Header("보스 스탯")]
    public float speed = 1.5f;
    public int maxHp = 800;
    public int currentHp;

    [Header("스페셜 무브 (낙하 공격)")]
    public float specialInterval = 12f;
    public float castTime = 0.5f;       // 사라지기 전 캐스팅(준비) 시간
    public float riseTime = 1.5f;       // 사라져 있는(체공) 시간
    public float aoeRadius = 4f;        // 낙하 타격 반경
    public int aoeDamage = 30;          // 낙하 데미지
    public float idleAfter = 1.5f;      // 낙하 후 후딜레이(정지) 시간

    [Header("이펙트 & 프리팹")]
    public GameObject warningCirclePrefab; // 낙하 지점 경고용 (빨간 원) 프리팹

    Rigidbody2D rigid;
    SpriteRenderer spriter;
    Collider2D coll;
    Animator anim; // ★ 애니메이터 연동
    Transform target;

    bool isLive = true;
    bool isInvincible = false;
    bool isActing = false;
    float specialTimer = 0f;

    void Awake()
    {
        rigid = GetComponent<Rigidbody2D>();
        coll = GetComponent<Collider2D>();

        // ★ 여기 두 줄이 변경되었습니다! (자식 오브젝트에 있는 컴포넌트까지 싹 다 뒤져서 찾아냅니다)
        spriter = GetComponentInChildren<SpriteRenderer>();
        anim = GetComponentInChildren<Animator>();
    }

    public void Init(int extraLevel)
    {
        maxHp += extraLevel * 100;
        currentHp = maxHp;
        speed += extraLevel * 0.05f;

        if (GameManager.instance != null && GameManager.instance.player != null)
            target = GameManager.instance.player.transform;

        isLive = true;
        isInvincible = false;
        isActing = false;
        specialTimer = 0f;
        transform.localScale = Vector3.one * 2f;
        if (coll != null) coll.enabled = true;
        if (rigid != null) rigid.simulated = true;
        if (spriter != null) spriter.color = Color.white;
    }

    void Update()
    {
        if (!isLive || target == null || isActing) return;
        if (GameManager.instance == null || !GameManager.instance.isLive) return;

        specialTimer += Time.deltaTime;
        if (specialTimer >= specialInterval)
        {
            specialTimer = 0f;
            StartCoroutine(SpecialMoveRoutine());
        }
    }

    void FixedUpdate()
    {
        if (!isLive || target == null || isActing)
        {
            if (anim != null) anim.SetBool("isWalk", false);
            return;
        }
        if (GameManager.instance == null || !GameManager.instance.isLive) return;

        Vector2 dir = ((Vector2)target.position - rigid.position).normalized;
        rigid.MovePosition(rigid.position + dir * speed * Time.fixedDeltaTime);

        // ★ 강제 재생(Play)으로 인해 꼬이지 않도록, 걷기 상태를 확실히 전달
        if (anim != null && anim.GetCurrentAnimatorStateInfo(0).IsName("Idle"))
            anim.SetBool("isWalk", true);
        else if (anim != null)
            anim.SetBool("isWalk", true);
    }

    void LateUpdate()
    {
        if (!isLive || target == null || isActing) return;

        // ★ 유체이탈 방지: 그림만 뒤집지 말고, 몸통(Scale) 전체를 뒤집어줍니다!
        float scaleX = Mathf.Abs(transform.localScale.x);

        // Bringer of Death는 원본 그림이 왼쪽을 바라봅니다.
        // 플레이어가 보스보다 오른쪽에 있으면 스케일 X를 마이너스로 만들어서 뒤집습니다.
        if (target.position.x > transform.position.x)
        {
            transform.localScale = new Vector3(-scaleX, transform.localScale.y, 1f);
        }
        else
        {
            transform.localScale = new Vector3(scaleX, transform.localScale.y, 1f);
        }
    }

    IEnumerator SpecialMoveRoutine()
    {
        isActing = true;
        isInvincible = true;
        if (rigid != null) rigid.linearVelocity = Vector2.zero;
        if (anim != null) anim.SetBool("isWalk", false);

        // ========================================================
        // ★ 1) 캐스팅(기 모으기) 모션 강제 재생! (화살표 무시)
        if (anim != null) anim.Play("Cast", -1, 0f);
        // ========================================================

        yield return new WaitForSeconds(castTime);
        if (!isLive) yield break;

        // 2) 완벽하게 사라지기 
        if (spriter != null) spriter.color = new Color(1, 1, 1, 0);
        if (coll != null) coll.enabled = false;

        // 3) 플레이어 위치에 타겟팅 및 경고 범위 표시
        Vector2 dropPos = target != null ? (Vector2)target.position : (Vector2)transform.position;
        GameObject warning = null;
        if (warningCirclePrefab != null)
        {
            warning = Instantiate(warningCirclePrefab, dropPos, Quaternion.identity);
            warning.transform.localScale = new Vector3(aoeRadius * 2f, aoeRadius * 2f, 1f);
        }

        // 4) 하늘에서 체공하며 대기
        yield return new WaitForSeconds(riseTime);
        if (!isLive) { if (warning) Destroy(warning); yield break; }

        // 5) 경고 마크 지우고, 타겟 위치로 나타나기
        if (warning != null) Destroy(warning);
        transform.position = dropPos;
        if (spriter != null) spriter.color = Color.white;
        if (coll != null) coll.enabled = true;

        // ========================================================
        // ★ 낙하(찍기) 공격 모션 강제 재생!
        if (anim != null) anim.Play("Attack", -1, 0f);
        // ========================================================

        // 6) 찍는 모션과 타격 판정 타이밍 맞추기 (약 0.2초 딜레이)
        yield return new WaitForSeconds(0.2f);

        Collider2D[] hits = Physics2D.OverlapCircleAll(dropPos, aoeRadius);
        foreach (var h in hits)
        {
            if (h.CompareTag("Player") && GameManager.instance.player != null)
                GameManager.instance.player.TakeDamage(aoeDamage);
        }

        // 7) 공격 후 후딜레이(잠시 멈춤)
        yield return new WaitForSeconds(idleAfter);

        isInvincible = false;
        isActing = false;
    }

    public void TakeDamage(int damageAmount)
    {
        if (!isLive || isInvincible) return;
        currentHp -= damageAmount;

        if (spriter != null)
        {
            spriter.color = new Color(1f, 0.3f, 0.3f);
            Invoke("ResetColor", 0.1f);
        }

        // ★ 피격(Hurt) 모션 강제 재생! (단, 스페셜 공격 중이 아닐 때만)
        if (anim != null && !isActing) anim.Play("Hurt", -1, 0f);

        if (currentHp <= 0) Die();
    }

    void ResetColor() { if (spriter != null && isLive && !isActing) spriter.color = Color.white; }

    public void ApplyStun(float duration) { }

    void Die()
    {
        isLive = false;
        if (coll != null) coll.enabled = false;
        if (rigid != null) rigid.simulated = false;

        // ★ 사망(Death) 모션 강제 재생!
        if (anim != null) anim.Play("Death", -1, 0f);
        else if (spriter != null) spriter.color = Color.gray;

        // ... (아래 아이템 드롭 코드는 기존과 동일) ...
        if (GameManager.instance != null && GameManager.instance.pool != null)
        {
            for (int i = 0; i < 10; i++)
            {
                GameObject gem = GameManager.instance.pool.Get(2);
                gem.transform.position = transform.position + (Vector3)(Random.insideUnitCircle * 1.5f);
            }
            GameManager.instance.TryDropItem(transform.position);
        }
        Destroy(gameObject, 1.5f);
    }

    // ★ 에디터에서 낙하 타격 범위를 시각적으로 확인하는 기즈모
    void OnDrawGizmosSelected()
    {
        Gizmos.color = new Color(1, 0, 0, 0.3f);
        Gizmos.DrawSphere(transform.position, aoeRadius);
    }
}